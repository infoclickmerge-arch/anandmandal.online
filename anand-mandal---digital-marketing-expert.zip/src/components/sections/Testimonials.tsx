import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    text: "Anand completely transformed our lead generation process. Within 3 months of taking over our Meta Ads, our cost per lead dropped by 40% and lead quality improved significantly.",
    name: "Rahul Sharma",
    business: "Interior Design Studio",
    location: "Mumbai, India",
    rating: 5,
  },
  {
    text: "The website Anand built for our hotel is not just beautiful, it converts. Direct bookings have gone up 4x since launch, and his Google Ads strategy is bringing in high-intent travelers.",
    name: "Priya Desai",
    business: "Boutique Hotel",
    location: "Goa, India",
    rating: 5,
  },
  {
    text: "We were struggling to scale our e-commerce store until Anand stepped in. His data-driven approach to Facebook Ads helped us hit our revenue targets faster than we expected.",
    name: "Amit Patel",
    business: "Premium Furniture",
    location: "Delhi, India",
    rating: 5,
  },
];

export function Testimonials() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section id="testimonials" className="py-32 bg-background-alt border-y border-white/5 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6 md:px-12 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Client <span className="text-gradient-primary">Success Stories</span>
          </h2>
          <p className="text-text-muted text-lg">
            Don't just take my word for it. Hear from the business owners who have scaled their revenue with my strategies.
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div className="absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 text-primary/20">
            <Quote size={120} />
          </div>

          <div className="relative min-h-[300px] flex items-center justify-center p-8 md:p-12 glass rounded-3xl border border-white/10">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.5 }}
                className="text-center"
              >
                <div className="flex justify-center gap-1 mb-8">
                  {[...Array(testimonials[current].rating)].map((_, i) => (
                    <Star key={i} size={24} className="fill-primary text-primary" />
                  ))}
                </div>
                
                <p className="text-xl md:text-3xl font-medium leading-relaxed mb-10 italic text-white/90">
                  "{testimonials[current].text}"
                </p>
                
                <div>
                  <h4 className="text-xl font-bold text-white mb-1">{testimonials[current].name}</h4>
                  <p className="text-primary font-medium">{testimonials[current].business}</p>
                  <p className="text-sm text-text-muted">{testimonials[current].location}</p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-6 mt-10">
            <button 
              onClick={prev}
              className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 hover:border-primary/50 transition-colors"
            >
              <ChevronLeft size={24} />
            </button>
            
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    i === current ? 'bg-primary w-8' : 'bg-white/20 hover:bg-white/40'
                  }`}
                />
              ))}
            </div>

            <button 
              onClick={next}
              className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 hover:border-primary/50 transition-colors"
            >
              <ChevronRight size={24} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
