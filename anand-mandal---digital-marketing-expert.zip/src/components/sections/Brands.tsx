import { motion } from 'motion/react';

const brandLogos = [
  '1yM33DkidzsY9J8kkkExjcsgCtyAcyUoY',
  '1t0FBgn2-nn1fzGI2U2BRpwk7YJKcMLga',
  '1aWPsYrbDDafpCscC6XJew3DiCJFkjVTC',
  '1k3_v96fnHMPv93hcSbNca5XWXIZugk4x',
  '18ZVOPPCR1FsqRqq4tHowQ6MlGcw7ls1r',
  '1Q_qiew3FmMoHnHz7TuYk0XxBndCNygEb',
  '1h3N3crAEIBCU9wmcOSuJFdacesesb2t4',
  '1ATFXSeDdT1wbx-Y_TWExncFInCD5IF12',
  '1s1gBXZOyEGtbn_EsRD8Zkl4YhCrbCoog',
  '1y828hLlPe_fwaBuqbvBDSVdffnD0umLF',
  '1ONJFgMsCfV6PYKjlm65PYQP3Orw-CWdC',
  '1VtoF8p5HiY4EE4c8xN7tPguVWwDajhmD',
];

export function Brands() {
  return (
    <section className="py-16 bg-surface/50 border-y border-white/5 overflow-hidden">
      <div className="container mx-auto px-6 md:px-12 mb-10 text-center">
        <h3 className="text-2xl md:text-3xl font-bold text-white/90">
          Brands I've <span className="text-gradient-primary">Worked With</span>
        </h3>
      </div>
      
      <div className="relative flex overflow-x-hidden group">
        <div className="animate-marquee flex w-max whitespace-nowrap items-center gap-16 py-4">
          {[...brandLogos, ...brandLogos].map((id, index) => (
            <div 
              key={`${id}-${index}`} 
              className="flex-none w-40 h-20 relative flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-300"
            >
              <img
                src={`https://lh3.googleusercontent.com/d/${id}`}
                alt={`Brand logo ${index + 1}`}
                className="max-w-full max-h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          ))}
        </div>
        
        {/* Gradient fades for the edges */}
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-background to-transparent pointer-events-none" />
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-background to-transparent pointer-events-none" />
      </div>
    </section>
  );
}
