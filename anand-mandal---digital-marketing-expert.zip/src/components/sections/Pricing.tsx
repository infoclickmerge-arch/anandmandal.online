import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';
import { scrollToSection } from '../../lib/utils';

export function Pricing() {
  return (
    <section className="py-32 relative">
      <div className="container mx-auto px-6 md:px-12">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass rounded-[3rem] p-10 md:p-16 border border-white/10 text-center relative overflow-hidden"
          >
            {/* Green Accent Divider */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
            
            <div className="inline-block px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 text-primary text-sm font-medium mb-8">
              Investment
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Custom <span className="text-gradient-primary">Quotes Only</span>
            </h2>
            
            <p className="text-text-muted text-lg max-w-2xl mx-auto mb-12">
              Every business is unique. I don't believe in one-size-fits-all packages. Let's discuss your goals, and I'll create a tailored strategy that guarantees ROI.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-12">
              <div className="flex items-center gap-2 text-white/80">
                <CheckCircle2 size={20} className="text-primary" />
                <span>Tailored Strategy</span>
              </div>
              <div className="flex items-center gap-2 text-white/80">
                <CheckCircle2 size={20} className="text-primary" />
                <span>Dedicated Support</span>
              </div>
              <div className="flex items-center gap-2 text-white/80">
                <CheckCircle2 size={20} className="text-primary" />
                <span>Transparent Reporting</span>
              </div>
            </div>
            
            <a
              href="#contact"
              onClick={(e) => scrollToSection(e, '#contact')}
              className="inline-block px-10 py-5 rounded-full bg-primary text-background font-bold text-lg hover:bg-primary-light transition-all duration-300 glow-primary"
            >
              Request Pricing
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
