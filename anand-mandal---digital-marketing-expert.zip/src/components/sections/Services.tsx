import { motion } from 'motion/react';
import { Target, MonitorPlay, Search, Layout, LineChart } from 'lucide-react';

const services = [
  {
    title: 'Lead Generation',
    description: 'High-quality, qualified leads that convert into paying customers using data-driven funnels.',
    icon: Target,
  },
  {
    title: 'Meta Ads (FB & IG)',
    description: 'Scroll-stopping creatives and laser-targeted campaigns to maximize your ROAS.',
    icon: MonitorPlay,
  },
  {
    title: 'Google Ads',
    description: 'Capture high-intent search traffic and dominate the top of Google search results.',
    icon: Search,
  },
  {
    title: 'SEO',
    description: 'Long-term organic growth strategies to rank higher and build sustainable traffic.',
    icon: LineChart,
  },
  {
    title: 'Website Design & Dev',
    description: 'Fast, responsive, and conversion-optimized websites that turn visitors into buyers.',
    icon: Layout,
  },
];

export function Services() {
  return (
    <section id="services" className="py-32 relative">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Premium <span className="text-gradient-primary">Digital Services</span>
          </h2>
          <p className="text-text-muted text-lg">
            From running high-converting ad campaigns to building result-driven websites, I bring strategy, creativity, and data together to grow your brand.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative p-8 rounded-3xl bg-surface border border-white/5 hover:border-primary/50 transition-all duration-500 hover:-translate-y-2 overflow-hidden"
            >
              {/* Hover Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-background border border-white/10 flex items-center justify-center mb-6 group-hover:border-primary/30 group-hover:text-primary transition-colors duration-300">
                  <service.icon size={28} className="text-white group-hover:text-primary transition-colors duration-300" />
                </div>
                
                <h3 className="text-2xl font-semibold mb-4 text-white group-hover:text-primary-light transition-colors duration-300">
                  {service.title}
                </h3>
                
                <p className="text-text-muted leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
