import { motion } from 'motion/react';
import { Users, Target, TrendingUp, BarChart, ShieldCheck, Zap } from 'lucide-react';

const benefits = [
  {
    title: 'Massive Audience Reach',
    description: 'Connect with billions of active users daily. Facebook provides an unparalleled platform to reach potential customers where they already spend their time.',
    icon: Users,
  },
  {
    title: 'Laser-Focused Targeting',
    description: 'Target your ideal customers based on demographics, interests, behaviors, and location to ensure your ad spend is highly efficient.',
    icon: Target,
  },
  {
    title: 'Cost-Effective Marketing',
    description: 'Whether you have a small or large budget, Facebook ads allow you to control your daily spend and get the most out of every dollar.',
    icon: TrendingUp,
  },
  {
    title: 'Measurable ROI',
    description: 'Track every click, lead, and sale. Facebook\'s robust analytics let you see exactly how your campaigns are performing in real-time.',
    icon: BarChart,
  },
  {
    title: 'Build Brand Loyalty',
    description: 'Engage directly with your audience, build trust, and foster long-term relationships that turn one-time buyers into loyal advocates.',
    icon: ShieldCheck,
  },
  {
    title: 'Fast Results',
    description: 'Unlike organic strategies that take months, Facebook ads can start driving targeted traffic and generating leads within hours of launching.',
    icon: Zap,
  },
];

export function FacebookAds() {
  return (
    <section id="facebook-ads" className="py-24 relative bg-background-alt">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight"
          >
            Why Should You Go for <span className="text-gradient-primary">Facebook Advertisement</span> for Your Small Business?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted text-lg"
          >
            Unlock exponential growth by leveraging the world's most powerful advertising platform tailored for small businesses.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="p-8 rounded-3xl bg-surface border border-white/5 hover:border-primary/30 transition-all duration-300 group"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <benefit.icon className="text-primary w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-primary-light transition-colors">
                {benefit.title}
              </h3>
              <p className="text-text-muted leading-relaxed">
                {benefit.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
