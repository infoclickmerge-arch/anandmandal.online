import { motion } from 'motion/react';
import { GLSLHills } from '../ui/glsl-hills';
import { ArrowRight } from 'lucide-react';
import { scrollToSection } from '../../lib/utils';

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-32 pb-20 overflow-hidden">
      {/* GLSL Background */}
      <div className="absolute inset-0 z-0 opacity-40">
        <GLSLHills speed={0.3} cameraZ={100} />
      </div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-background/20 via-background/60 to-background pointer-events-none" />
      
      {/* Subtle green glow */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] pointer-events-none z-0" />

      <div className="container mx-auto px-6 md:px-12 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-block px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 text-primary text-sm font-medium mb-6"
          >
            Digital Marketing Expert & Web Designer
          </motion.div>
          
          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            7 Years. 105+ Clients. <br />
            <span className="text-gradient-primary">20,000+ Leads</span> Generated.
          </h1>
          
          <p className="text-xl text-text-muted mb-8 max-w-xl leading-relaxed">
            Hi, I'm Anand Mandal. I help businesses generate high-quality leads and scale online through high-converting Meta & Google Ads and result-driven websites.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <a
              href="#contact"
              onClick={(e) => scrollToSection(e, '#contact')}
              className="px-8 py-4 rounded-full bg-primary text-background font-semibold text-lg hover:bg-primary-light transition-all duration-300 glow-primary flex items-center gap-2 group"
            >
              Get Free Consultation
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#case-studies"
              onClick={(e) => scrollToSection(e, '#case-studies')}
              className="px-8 py-4 rounded-full bg-white/5 text-white font-semibold text-lg border border-white/10 hover:bg-white/10 transition-all duration-300"
            >
              View Case Studies
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
          className="relative hidden lg:block"
        >
          <div className="relative w-full aspect-[4/5] rounded-3xl overflow-hidden border border-white/10 glass">
            {/* Using a high quality professional placeholder from Unsplash */}
            <img 
              src="https://lh3.googleusercontent.com/d/1hbuV4xHWMedjwfjeTaION0u6KlwKIwVL" 
              alt="Anand Mandal - Digital Marketing Expert" 
              className="w-full h-full object-cover opacity-80 mix-blend-luminosity hover:mix-blend-normal transition-all duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
            
            {/* Floating Badge */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute bottom-8 left-8 right-8 glass rounded-2xl p-6 border border-primary/20"
            >
              <div className="text-primary font-bold text-2xl mb-1">7+ Years</div>
              <div className="text-sm text-text-muted">Experience in Meta & Google Ads</div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
