import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { scrollToSection } from '../../lib/utils';

const cases = [
  {
    industry: 'Interior Design',
    results: '350% Increase in Leads',
    timeline: '3 Months',
    summary: 'Revamped Meta Ads strategy and optimized landing page to capture high-ticket interior design clients.',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=800&auto=format&fit=crop',
  },
  {
    industry: 'Luxury Hotel',
    results: '4x Direct Bookings',
    timeline: '6 Months',
    summary: 'Implemented a full-funnel Google Ads campaign targeting luxury travelers, reducing OTA dependency.',
    image: 'https://images.unsplash.com/photo-1542314831-c6a4d27ce6a2?q=80&w=800&auto=format&fit=crop',
  },
  {
    industry: 'Premium Furniture',
    results: '2.5x ROAS',
    timeline: '4 Months',
    summary: 'Scaled e-commerce sales through dynamic product ads and retargeting on Facebook and Instagram.',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=800&auto=format&fit=crop',
  },
  {
    industry: 'E-commerce Brand',
    results: '500k+ Monthly Revenue',
    timeline: '8 Months',
    summary: 'Built a high-converting Shopify store and scaled traffic using a mix of SEO and Meta Ads.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&auto=format&fit=crop',
  },
];

export function CaseStudies() {
  return (
    <section id="case-studies" className="py-32">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Proven <span className="text-gradient-primary">Results</span>
            </h2>
            <p className="text-text-muted text-lg">
              Real numbers, real growth. See how I've helped businesses scale their revenue and dominate their market.
            </p>
          </div>
          <a href="#contact" onClick={(e) => scrollToSection(e, '#contact')} className="text-primary hover:text-primary-light font-medium flex items-center gap-2 transition-colors">
            View All Cases <ArrowRight size={20} />
          </a>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {cases.map((study, index) => (
            <motion.div
              key={study.industry}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group rounded-3xl overflow-hidden bg-surface border border-white/5 hover:border-primary/50 transition-all duration-500"
            >
              <div className="relative h-64 overflow-hidden">
                <div className="absolute inset-0 bg-background/20 group-hover:bg-transparent transition-colors duration-500 z-10" />
                <img 
                  src={study.image} 
                  alt={study.industry}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 z-20 px-4 py-1.5 rounded-full bg-background/80 backdrop-blur-md border border-white/10 text-xs font-semibold tracking-wider uppercase">
                  {study.industry}
                </div>
              </div>
              
              <div className="p-8">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-2xl font-bold text-primary">{study.results}</h3>
                  <span className="text-sm text-text-muted font-medium bg-white/5 px-3 py-1 rounded-full">{study.timeline}</span>
                </div>
                
                <p className="text-text-muted mb-8 line-clamp-2">
                  {study.summary}
                </p>
                
                <button className="flex items-center gap-2 text-white font-medium group-hover:text-primary transition-colors">
                  View Details
                  <ArrowRight size={18} className="transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
