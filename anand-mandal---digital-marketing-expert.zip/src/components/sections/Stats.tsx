import { useEffect, useState, useRef } from 'react';
import { motion, useInView } from 'motion/react';

function Counter({ value, label, suffix = '+' }: { value: number; label: string; suffix?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const duration = 2000; // 2 seconds
      const increment = value / (duration / 16); // 60fps

      const timer = setInterval(() => {
        start += increment;
        if (start >= value) {
          setCount(value);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 16);

      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-5xl font-bold text-white mb-2">
        {count.toLocaleString()}{suffix}
      </div>
      <div className="text-primary font-medium tracking-wide uppercase text-sm">
        {label}
      </div>
    </div>
  );
}

export function Stats() {
  return (
    <section className="py-20 bg-background-alt border-y border-white/5 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[300px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-6 md:px-12 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-6">
          <Counter value={7} label="Years Experience" />
          <Counter value={105} label="Happy Clients" />
          <Counter value={20000} label="Leads Generated" />
          <Counter value={100} label="Case Studies" />
        </div>
      </div>
    </section>
  );
}
