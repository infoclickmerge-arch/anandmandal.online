import { motion } from 'motion/react';
import { Home, Building2, Sofa, ShoppingCart, Sparkles } from 'lucide-react';

const industries = [
  { name: 'Interior Designing', icon: Home },
  { name: 'Hotels & Hospitality', icon: Building2 },
  { name: 'Furniture', icon: Sofa },
  { name: 'E-commerce', icon: ShoppingCart },
  { name: 'And More...', icon: Sparkles },
];

export function Industries() {
  return (
    <section className="py-24 bg-background-alt border-y border-white/5">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="md:w-1/3">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Industries <br />
              <span className="text-gradient-primary">I Serve</span>
            </h2>
            <p className="text-text-muted">
              Tailored strategies for specific niches to guarantee maximum ROI and market dominance.
            </p>
          </div>
          
          <div className="md:w-2/3 grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-6 w-full">
            {industries.map((industry, index) => (
              <motion.div
                key={industry.name}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="flex flex-col items-center justify-center p-6 rounded-2xl bg-surface border border-white/5 hover:border-primary/30 transition-colors group"
              >
                <industry.icon size={32} className="text-text-muted group-hover:text-primary mb-4 transition-colors" />
                <span className="text-sm font-medium text-center text-white/80 group-hover:text-white transition-colors">
                  {industry.name}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
