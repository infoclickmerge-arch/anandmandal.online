import { motion } from 'motion/react';
import { ExternalLink } from 'lucide-react';

const designs = [
  {
    id: '1ZlRw4q5mGrwNrh75JIdsmMD9cM-u4Pe6',
    title: 'Real Estate Website',
    category: 'Real Estate',
    link: 'https://rbsystems.in/',
  },
  {
    id: '1yFVQsKpSdFU0bCbl3jsM_U0l7sl3F24L',
    title: 'Travel Agency Website',
    category: 'Travel',
    link: 'http://theaonetravels.com/',
  },
  {
    id: '1zF3sCnU2NPuVjOwbcw2J6oIeHdPLtyCz',
    title: 'Astrology Website',
    category: 'Astrology',
    link: 'https://srikalimathaastrology.com/',
  },
  {
    id: '1A2xVxAvJq1OWiSZj-IvdzZ_LptooC2fN',
    title: 'Real Estate Platform',
    category: 'Real Estate',
  },
  {
    id: '1d4szB28fx0HSk-anZCX9TyqEEAHiiwjJ',
    title: 'SaaS Landing Page',
    category: 'Technology',
  },
];

export function WebsiteDesigns() {
  return (
    <section id="website-designs" className="py-24 bg-surface/30 border-y border-white/5">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
          >
            Featured <span className="text-gradient-primary">Website Designs</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted text-lg"
          >
            A showcase of high-converting, aesthetically pleasing websites crafted to elevate brand presence and drive results.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {designs.map((design, index) => (
            <motion.div
              key={design.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`group relative rounded-2xl overflow-hidden bg-surface border border-white/10 hover:border-primary/50 transition-all duration-500 ${
                index === 0 || index === 1 ? 'md:col-span-1 lg:col-span-1' : ''
              } ${index === 3 || index === 4 ? 'md:col-span-1 lg:col-span-1' : ''}`}
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-background-alt">
                <a 
                  href={design.link || '#'} 
                  target={design.link ? "_blank" : "_self"}
                  rel={design.link ? "noopener noreferrer" : ""}
                  className="absolute inset-0 bg-background/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 flex items-center justify-center backdrop-blur-sm"
                >
                  <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center transform scale-0 group-hover:scale-100 transition-transform duration-500 delay-100">
                    <ExternalLink className="text-background w-5 h-5" />
                  </div>
                </a>
                <img
                  src={`https://lh3.googleusercontent.com/d/${design.id}`}
                  alt={design.title}
                  className="w-full h-full object-cover object-top transform group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6 absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background via-background/90 to-transparent pt-12 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 z-20">
                <div className="text-xs font-semibold text-primary mb-1 uppercase tracking-wider">
                  {design.category}
                </div>
                <h3 className="text-lg font-bold text-white">
                  {design.title}
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
