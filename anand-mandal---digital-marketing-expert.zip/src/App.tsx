/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar } from './components/layout/Navbar';
import { Hero } from './components/sections/Hero';
import { Stats } from './components/sections/Stats';
import { Services } from './components/sections/Services';
import { Brands } from './components/sections/Brands';
import { Industries } from './components/sections/Industries';
import { FacebookAds } from './components/sections/FacebookAds';
import { CaseStudies } from './components/sections/CaseStudies';
import { WebsiteDesigns } from './components/sections/WebsiteDesigns';
import { Testimonials } from './components/sections/Testimonials';
import { Pricing } from './components/sections/Pricing';
import { Contact } from './components/sections/Contact';
import { Footer } from './components/layout/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-background text-text-main font-sans selection:bg-primary/30 selection:text-primary-light">
      <Navbar />
      <main>
        <Hero />
        <Stats />
        <Services />
        <Brands />
        <Industries />
        <FacebookAds />
        <CaseStudies />
        <WebsiteDesigns />
        <Testimonials />
        <Pricing />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

